package ksmori.hu.ait.spades.view;

import android.content.Context;
import android.support.percent.PercentRelativeLayout;
import android.util.AttributeSet;

public class SpadesGameRootLayout extends PercentRelativeLayout {

    public SpadesGameRootLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}