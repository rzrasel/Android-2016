package ksmori.hu.ait.spades.presenter;

import ksmori.hu.ait.spades.SpadesGameScreen;

public class SpadesPresenter extends Presenter<SpadesGameScreen> {

    public SpadesPresenter(String gameID, boolean isHostPlayer) {

    }
}